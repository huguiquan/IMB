package com.tarena.service.impl;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.tarena.dao.GalleryMapper;
import com.tarena.dao.QuestionMapper;
import com.tarena.entity.Question;
import com.tarena.service.QuestionService;
import com.tarena.util.PageUtil;
import com.tarena.vo.Page;
import com.tarena.vo.Result;

@Service("questionService")
public class QuestionServiceImpl implements QuestionService{
	private ReentrantReadWriteLock rwLock=new ReentrantReadWriteLock();
	@Autowired
	private RedisTemplate redisTemplate;
	@Resource(name="questionMapper")
	private QuestionMapper questionMapper;
	@Resource(name="galleryMapper")
	private GalleryMapper galleryMapper;
	
	@Resource(name="pageUtil")
	private PageUtil pageUtil;
	
	
	@Override
	public Result findQuestionsByPage(Page page) {
		
		//System.out.println("进入service的findQuestionsByPage");
		Result result=new Result();
		//currentPage和roleKeyword由用户提供
		
		String questionKW=page.getQuestionKeyword();
		questionKW="undefined".equals(questionKW)? "%%" : "%"+questionKW+"%";
		page.setQuestionKeyword(questionKW);
		
		System.out.println("questionKW"+questionKW);
		
		//获取pageSize,从属性文件取
		page.setPageSize(this.pageUtil.getPageSize());
		
		//查询数据库获取总记录数
		int totalCount=this.questionMapper.getCount(page);
		//System.out.println(totalCount);
		page.setTotalCount(totalCount);
		
		//计算总页数
		int totalPage=(totalCount%pageUtil.getPageSize()==0)? (totalCount/pageUtil.getPageSize()) : (totalCount/pageUtil.getPageSize())+1;
		page.setTotalPage(totalPage);
		//计算前一页
		if(page.getCurrentPage()==1){
			page.setPreviousPage(1);
		}else{
			page.setPreviousPage(page.getCurrentPage()-1);
		}		
		//计算后一页
		if(page.getCurrentPage()==totalPage){
			page.setNextPage(totalPage);
		}else{
			page.setNextPage(page.getCurrentPage()+1);
		}
		//查询数据库获取当前页的那页数据(集合)
		
		
		//List<Question> questions=questionMapper.getQuestionsByPage(page);
	
		
		List<Question> questions=null;
		//设置key的序列化方式,采用字符串方式,可读性好
		this.redisTemplate.setKeySerializer(new StringRedisSerializer());
		//先从redis缓存中查询是否有指定key的缓存数据
		questions=(List<Question>)redisTemplate.opsForValue().get("allQuestions");
		//双重检测,双重校验锁
		if(questions==null){
			{
				//从redis获取数据
				questions=(List<Question>)redisTemplate.opsForValue().get("allQuestions");
				if(questions==null){
				    System.out.println("查询数据...");
					//说明redis指定key的缓存数据不存在
				    rwLock.writeLock().lock();
					questions=questionMapper.getQuestionsByPage(page);
					//把数据库查询出来的数据放入redis中,并设置reids的key存活时间为30秒
					redisTemplate.opsForValue().set("allQuestions",questions,30,TimeUnit.SECONDS);
					rwLock.writeLock().unlock();
				}else{
					System.out.println("查询的缓存");
				}
			}
		}else{
			System.out.println("查询的缓存");
		}		
		
		
		
		
		
		
		//
		
		
		for(Question q:questions) {
			
			Integer qCid=q.getqCid();
			
			String qCategory=galleryMapper.getCategoryNameById(qCid);
			//System.out.println("问题类别id:"+qCid+","+qCategory);
			q.setqCategory(qCategory);
		}
		
		
		page.setData(questions);
		//计算html页面上分页组件的超链接个数			
		
		page.setNums(pageUtil.getFenYe_a_Num(page.getCurrentPage(), page.getPageSize(), totalCount, totalPage));
		
		System.out.println("page:"+page);
		
		
		result.setData(page);
		return result;
			
	
	}


	@Transactional(propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	@Override
	public Result addQuestion(String questionName,String answer,Integer id) {
		// TODO Auto-generated method stub
		
		Result result=new Result();
		
		Question question=new Question();
		question.setqName(questionName);
		question.setqData(answer);
		question.setqCid(id);
		Integer rows=questionMapper.addQuestion(question);
		
		result.setStatus(1);
		result.setMessage("添加成功");
		
		return result;
	}

	
	@Override
	public Result findQuestionById(Integer id) {
		// TODO Auto-generated method stub
	
		Result result=new Result();
		
		Question question=questionMapper.findQuestionById(id);
		//
		//
		result.setStatus(1);
		result.setMessage("更新题目成功了");
		result.setData(question);
		
		return result;
	}
	
	

	@Transactional(propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	@Override
	public Result updateQuestion(Question question) {
		// TODO Auto-generated method stub
	
		Result result=new Result();
		Integer cid=question.getqCid();
		String qCategory=galleryMapper.getCategoryNameById(cid);
		question.setqCategory(qCategory);
		
		questionMapper.updateQuestion(question);
		
		result.setStatus(1);
		result.setMessage("更新题目成功了");
		result.setData(question);
		
		return result;
	}


	@Transactional(propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	@Override
	public Result deleteQuestion(Integer questionId) {
		// TODO Auto-generated method stub
		
		Result result=new Result();
		
		questionMapper.deleteQuestion(questionId);
		
		result.setStatus(1);
		result.setMessage("删除题目成功");
				
		return result;
	}

	
	
	
	
}
