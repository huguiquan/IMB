package com.tarena.service.impl;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.tarena.dao.GalleryMapper;
import com.tarena.entity.Gallery;
import com.tarena.service.GalleryService;
import com.tarena.util.PageUtil;
import com.tarena.vo.Page;
import com.tarena.vo.Result;

/**
 * @author Administrator
 *
 */
@Service("galleryService")
public class GalleryServiceImpl implements GalleryService {
	private ReentrantReadWriteLock rwLock=new ReentrantReadWriteLock();
	@Autowired
	private RedisTemplate redisTemplate;
	@Resource(name="pageUtil")
	private PageUtil pageUtil;
	
	@Resource(name="galleryMapper")
	private GalleryMapper galleryMapper;
	@Override
	public Result findGallerysByPage(Page page) {
		Result result=new Result();
		//currentPage和roleKeyword由用户提供
		String galleryKW=page.getGalleryKeyword();
		galleryKW="undefined".equals(galleryKW)? "%%" : "%"+galleryKW+"%";
		page.setGalleryKeyword(galleryKW);
		System.out.println("========"+galleryKW);
		//获取pageSize,从属性文件取
		page.setPageSize(this.pageUtil.getPageSize());
		//System.out.println(this.pageUtil.getPageSize()+"   "+this.pageUtil.getShowNum_a());
		//查询数据库获取总记录数
		int totalCount=this.galleryMapper.getCount(page);
		//System.out.println(totalCount);
		page.setTotalCount(totalCount);
		//计算总页数
		int totalPage=(totalCount%pageUtil.getPageSize()==0)? (totalCount/pageUtil.getPageSize()) : (totalCount/pageUtil.getPageSize())+1;
		page.setTotalPage(totalPage);
		//计算前一页
		if(page.getCurrentPage()==1){
			page.setPreviousPage(1);
		}else{
			page.setPreviousPage(page.getCurrentPage()-1);
		}		
		//计算后一页
		if(page.getCurrentPage()==totalPage){
			page.setNextPage(totalPage);
		}else{
			page.setNextPage(page.getCurrentPage()+1);
		}
		//查询数据库获取当前页的那页数据(集合)
		//List<Gallery> gallerys=galleryMapper.getGallerysByPage(page); 
		//
		List<Gallery> gallerys=null;
		//设置key的序列化方式,采用字符串方式,可读性好
		this.redisTemplate.setKeySerializer(new StringRedisSerializer());
		//先从redis缓存中查询是否有指定key的缓存数据
		gallerys=(List<Gallery>)redisTemplate.opsForValue().get("allGallerys");
		//双重检测,双重校验锁
		if(gallerys==null){
			{
				//从redis获取数据
				gallerys=(List<Gallery>)redisTemplate.opsForValue().get("allGallerys");
				if(gallerys==null){
				    System.out.println("查询数据...");
					//说明redis指定key的缓存数据不存在
				    rwLock.writeLock().lock();
					gallerys=this.galleryMapper.findAllGallerys();
					//把数据库查询出来的数据放入redis中,并设置reids的key存活时间为30秒
					redisTemplate.opsForValue().set("allGallerys",gallerys,30,TimeUnit.SECONDS);
					rwLock.writeLock().unlock();
				}else{
					System.out.println("查询的缓存");
				}
			}
		}else{
			System.out.println("查询的缓存");
		}
		
		//
		page.setData(gallerys);
		//计算html页面上分页组件的超链接个数			
		
		page.setNums(pageUtil.getFenYe_a_Num(page.getCurrentPage(), page.getPageSize(), totalCount, totalPage));
		
		System.out.println(page);
		result.setStatus(1);
		result.setData(page);
		return result;
	}
	
	@Transactional(propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	@Override
	public Result addGallery(String galleryName) {
		Result result=new Result();
		Gallery gallery=new Gallery();
	
		gallery.setcName(galleryName);
		int rowAffect=this.galleryMapper.addGallery(gallery);
		result.setStatus(1);
		result.setMessage("添加类别成功!");
		
		return result;
	}
	@Transactional(propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	@Override
	public Result updateGallery(Gallery gallery) {
		Result result=new Result();
		int rowAffect=this.galleryMapper.updateGallery(gallery);
		result.setStatus(1);
		result.setMessage("更新类别成功!");
		
		return result;
	}
	@Transactional(propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	@Override
	public Result deleteGallery(String galleryId) {
		Result result=new Result();
		int rowAffect=this.galleryMapper.deleteGallery(galleryId);
		result.setStatus(1);
		result.setMessage("删除题目类别成功!");
		return result;
	}
	@Override
	public Result findAllGallerys() {
		Result result=new Result();
		List<Gallery> gallerys=null;
		//设置key的序列化方式,采用字符串方式,可读性好
		this.redisTemplate.setKeySerializer(new StringRedisSerializer());
		//先从redis缓存中查询是否有指定key的缓存数据
		gallerys=(List<Gallery>)redisTemplate.opsForValue().get("allGallerys");
		//双重检测,双重校验锁
		if(gallerys==null){
			{
				//从redis获取数据
				gallerys=(List<Gallery>)redisTemplate.opsForValue().get("allGallerys");
				if(gallerys==null){
				    System.out.println("查询数据...");
					//说明redis指定key的缓存数据不存在
				    rwLock.writeLock().lock();
					gallerys=this.galleryMapper.findAllGallerys();
					//把数据库查询出来的数据放入redis中,并设置reids的key存活时间为30秒
					redisTemplate.opsForValue().set("allGallerys",gallerys,30,TimeUnit.SECONDS);
					rwLock.writeLock().unlock();
				}else{
					System.out.println("查询的缓存");
				}
			}
		}else{
			System.out.println("查询的缓存");
		}
		//
		result.setStatus(1);
		result.setData(gallerys);
		return result;
	}

}
