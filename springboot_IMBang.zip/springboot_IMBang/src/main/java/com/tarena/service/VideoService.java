package com.tarena.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;

import com.tarena.entity.Video;
import com.tarena.vo.Result;

public interface VideoService {
	
	//查询所有视频
	public List<Video> findAllVideos();

	//添加一个视频信息
	public boolean addVideo(Video metaData);

	//更新视频信息
	public Result updateVideo(Video video);

	//删除视频信息
	public Result deleteVideo(String videoId);
	
	

}
