package com.tarena.service.impl;

import java.io.File;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.tarena.dao.UserMapper;
import com.tarena.entity.Page;
import com.tarena.entity.User;
import com.tarena.service.UserService;
import com.tarena.util.CommonValue;
import com.tarena.util.PageUtil;
import com.tarena.util.PrintWriterUtil;
import com.tarena.util.UUIDUtil;
import com.tarena.util.UploadUtil;
import com.tarena.vo.Result;


@Service("userService")
public class UserServiceImpl implements UserService {
	private ReentrantReadWriteLock rwLock=new ReentrantReadWriteLock();
	@Autowired
	private RedisTemplate redisTemplate;
	@Resource(name="pageUtil")
	private PageUtil pageUtil;
	@Resource(name="userMapper")
	private UserMapper userMapper;

	@Override
	public Result login(String loginName, String password,HttpSession session) {
		Result result=new Result();
		
		User user=new User();
		user.setLoginName(loginName);
		user.setPassword(password);
		String id=this.userMapper.login(user);
		
		if(id!=null){
			
			result.setStatus(1);
			result.setMessage("登录成功");
			
		}else if(id==null){
			result.setStatus(0);
			result.setMessage("登录失败");
		}
		
		return result;
	}

	@Override
	public Result loginBack(String loginName, String password,HttpSession session) {
		Result result=new Result();
		
		User user=new User();
		user.setLoginName(loginName);
		user.setPassword(password);
		String id=this.userMapper.loginBack(user);
		
		if(id!=null){
			
			result.setStatus(1);
			result.setMessage("登录成功");
			
		}else if(id==null){
			result.setStatus(0);
			result.setMessage("登录失败");
		}
		
		return result;
	}
	@Override
	public Result registUser(String loginName, String password) {
        Result result=new Result();
		
        
		User user=new User();
		user.setId(UUIDUtil.getUUID());
		user.setLoginName(loginName);
		user.setPassword(password);
		
		this.userMapper.registUser(user);
		
		result.setStatus(1);
		result.setMessage("注册成功");
	
		return result;
		
	}

	@Override
	public Result findUserByName(String loginName) {
		Result result=new Result();
		int rows = this.userMapper.findUserByName(loginName);
		if(rows>0){
		result.setStatus(0);
		result.setMessage("该用户已存在!");
		}else{
			result.setStatus(1);
			result.setMessage("用户名可以使用!");
		}
		return result;
	}
     
	//添加所有用户信息，表单下载
		@Override
		public List<User> findAllUser() {
			List<User> users=null;
			//users=this.userMapper.findAllUser();
			//
			//List<User> users=null;
			//设置key的序列化方式,采用字符串方式,可读性好
			this.redisTemplate.setKeySerializer(new StringRedisSerializer());
			//先从redis缓存中查询是否有指定key的缓存数据
			users=(List<User>)redisTemplate.opsForValue().get("allUsers");
			//双重检测,双重校验锁
			if(users==null){
				{
					//从redis获取数据
					users=(List<User>)redisTemplate.opsForValue().get("allUsers");
					if(users==null){
					    System.out.println("查询数据...");
						//说明redis指定key的缓存数据不存在
					    rwLock.writeLock().lock();
						users=this.userMapper.findAllUser();;
						//把数据库查询出来的数据放入redis中,并设置reids的key存活时间为30秒
						redisTemplate.opsForValue().set("allUsers",users,30,TimeUnit.SECONDS);
						rwLock.writeLock().unlock();
					}else{
						System.out.println("查询的缓存");
					}
				}
			}else{
				System.out.println("查询的缓存");
			}		
			//
			System.out.println(users.size());
			return users;
		}

		@Override
		public void addUser(User user, HttpServletRequest request, HttpServletResponse response,MultipartFile picture) {
	     
			String realPath=request.getServletContext().getRealPath("/head");
			File realFile=new File(realPath);
			if(!realFile.exists()) realFile.mkdir();
			//预备必要的数据
			String uuid=UUIDUtil.getUUID();
			System.out.println("userId="+uuid);
			String oriFileName=null;
			String imageFileName=null;
			System.out.println("realPath"+realPath);
			if(picture==null || picture.isEmpty()){
				//给用户存储默认头像
				user.setHead("default.png");
			}else{
				//说明头像正常上传成功
				//获取图片的相关信息
				oriFileName=picture.getOriginalFilename();
				String contentType=picture.getContentType();
				long size=picture.getSize();
				//判断头像类型是否符合
				if(!CommonValue.contentTypes.contains(contentType)){
					//给客户端提示消息
					PrintWriterUtil.printMessageToClient(response, "文件类型不合格");
					return;
				}else if(size>4194304){
					//判断头像图片文件大小是否符合
					//给客户端提示消息
					PrintWriterUtil.printMessageToClient(response, "文件太大,请重新上传");
					return;
				}			
				//如果都符合就需要把图片做缩放并添加水印
				//File serverPath=new File(realPath,oriFileName);
				boolean flag=UploadUtil.uploadImage(picture, uuid, true, 64, realPath);
			    if(flag){
			    	//说明图片缩放后上传成功
					String originalExtendName=oriFileName.substring(oriFileName.lastIndexOf(".")+1);
					imageFileName=uuid+"."+originalExtendName;
			    	user.setHead(imageFileName);
			    }else{
			    	return;
			    }
			}
			try{
				user.setId(uuid);
				//给user对象存储必要的数据
				//给数据库的t_user表添加用户信息
				System.out.println("user");
				this.userMapper.addUser(user);
				
				
	      PrintWriterUtil.printMessageToClient(response,"用户添加成功!!");
			}catch(Exception e){
				//删除服务端的已经上传完的文件
				File deleteFile=new File(realPath+File.separator+imageFileName);
				if(deleteFile.exists()){
					deleteFile.delete();
				}
				e.printStackTrace();
				//能进catch,说明两次数据库操作,至少有一次不成功
				throw new RuntimeException(e);//用来使用spring的事物管理
			}		
	  
	     
			
			
			
		}

		@Override
		public Result findUsersByPage(Page page) {
		    Result result=new Result();
		
		    String ukw=page.getUserKeyword();
			ukw="undefined".equals(ukw)? "%%" : "%"+ukw+"%";
			page.setUserKeyword(ukw);
		
			//处理pageSize
			page.setPageSize(pageUtil.getPageSize());
			//处理totalCount
			int totalCount=this.userMapper.getCount(page);
			page.setTotalCount(totalCount);
			//处理tatalPage
			int totalPage=(totalCount%pageUtil.getPageSize()==0)? (totalCount/pageUtil.getPageSize()) : (totalCount/pageUtil.getPageSize())+1;
			page.setTotalPage(totalPage);
		    
			//查询当前页的数据
			//List<User> users=this.userMapper.getUserByPage(page);
			//
			List<User> users=null;
			//设置key的序列化方式,采用字符串方式,可读性好
			this.redisTemplate.setKeySerializer(new StringRedisSerializer());
			//先从redis缓存中查询是否有指定key的缓存数据
			users=(List<User>)redisTemplate.opsForValue().get("allUsers");
			//双重检测,双重校验锁
			if(users==null){
				{
					//从redis获取数据
					users=(List<User>)redisTemplate.opsForValue().get("allUsers");
					if(users==null){
					    System.out.println("查询数据...");
						//说明redis指定key的缓存数据不存在
					    rwLock.writeLock().lock();
						 users=this.userMapper.getUserByPage(page);
						//把数据库查询出来的数据放入redis中,并设置reids的key存活时间为30秒
						redisTemplate.opsForValue().set("allUsers",users,30,TimeUnit.SECONDS);
						rwLock.writeLock().unlock();
					}else{
						System.out.println("查询的缓存");
					}
				}
			}else{
				System.out.println("查询的缓存");
			}		
			//
			page.setData(users);
			
			result.setStatus(1);
			result.setData(page);
			return result;
		}

		@Override
		public void updateUser(User user, MultipartFile updatePicture, HttpServletRequest request,
				HttpServletResponse response) {
			String realPath=request.getServletContext().getRealPath("/head");
			File realFile=new File(realPath);
			if(!realFile.exists()){
				realFile.mkdir();
			}
			String oriFileName="";
			//上传文件
			if(updatePicture!=null  && !updatePicture.isEmpty()){
				//开始处理上传文件
				String contentType=updatePicture.getContentType();
				long size=updatePicture.getSize();
				if(!CommonValue.contentTypes.contains(contentType)){
					PrintWriterUtil.printMessageToClient(response, "图片格式不正确");
					return;
				}
				if(size>4194304){
					PrintWriterUtil.printMessageToClient(response, "文件太大");
					return;
				}
				boolean flag=UploadUtil.uploadImage(updatePicture, user.getId(), true, 64, realPath);
				if(!flag){
					PrintWriterUtil.printMessageToClient(response, "文件上传失败!!!");
					return;
				}else{
					oriFileName=updatePicture.getOriginalFilename();
					String extendName=oriFileName.substring(oriFileName.lastIndexOf(".")+1);
					user.setHead(user.getId()+"."+extendName);
				}
			}else{
				PrintWriterUtil.printMessageToClient(response, "必须选择文件上传");
				return;
			}		
			//处理数据库相关
			//更新用户信息
			this.userMapper.updateUser(user);
			
			//循环给中间表添加用户和角色对应关系
			
			PrintWriterUtil.printMessageToClient(response, "更新用户成功!!!");
			return;
			
		}

		@Override
		public Result deleteUser(String userId) {
			System.out.println(userId);
			Result result=new Result();
			this.userMapper.deleteUserByUserId(userId);
			result.setMessage("删除成功");
			result.setStatus(1);
			return result;
		}

		@Override
		public Result findUserById(String userId) {
			Result result=new Result();
			User user=this.userMapper.findUserById(userId);
			result.setStatus(1);
			result.setData(user);
			return result;
		}

}
