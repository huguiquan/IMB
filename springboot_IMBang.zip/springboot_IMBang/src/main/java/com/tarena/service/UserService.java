package com.tarena.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.multipart.MultipartFile;

import com.tarena.entity.Page;
import com.tarena.entity.User;
import com.tarena.vo.Result;

public interface UserService {
    //普通用户登录
	public Result login(String loginName, String password,HttpSession session);
    //前端用户注册
	public Result registUser(String loginName, String password);
	//后端用户登录
	public Result loginBack(String loginName, String password, HttpSession session);
	//通过用户名查找用户
	public Result findUserByName(String loginName);
	//查询所有用户信息，用excel下载
		public List<User> findAllUser();
		//添加用户
		public void addUser(User user, HttpServletRequest request, HttpServletResponse resoponse, MultipartFile addPicture);
		//查询所有用户信息
		public Result findUsersByPage(Page page);
		//用户编辑
		public void updateUser(User user, MultipartFile addPicture, HttpServletRequest request,
				HttpServletResponse response);
		public Result deleteUser(String userId);
		//根据id查询用户信息
		public Result findUserById(String userId);
	  
	
}
