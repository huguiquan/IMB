package com.tarena.service;

import com.tarena.entity.Gallery;
import com.tarena.vo.Page;
import com.tarena.vo.Result;

public interface GalleryService {
	//题目类别分页业务
	public Result findGallerysByPage(Page page);
    //添加题目类别业务
	public Result addGallery(String galleryName);
	//添加类别信息
	public Result updateGallery(Gallery gallery);
	//删除类别
	public Result deleteGallery(String galleryId);
	//查询所有的类别的信息(给新增题目使用)
	public Result findAllGallerys();
}
