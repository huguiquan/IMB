package com.tarena.service;

import com.tarena.entity.Question;
import com.tarena.vo.Page;
import com.tarena.vo.Result;


public interface QuestionService {

	//找到题目
	Result findQuestionsByPage(Page page);

	//添加题目
	Result addQuestion(String questionName, String answer, Integer id);

	//更新题目
	Result updateQuestion(Question question);

	//删除题目
	Result deleteQuestion(Integer questionId);

	//通过id找题目
	Result findQuestionById(Integer id);



	
	
}
