package com.tarena.service.impl;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.tarena.dao.VideoMapper;
import com.tarena.entity.Video;
import com.tarena.service.VideoService;
import com.tarena.util.PrintWriterUtil;
import com.tarena.util.UUIDUtil;
import com.tarena.vo.Result;

@Service("videoService")
public class VideoServiceImpl implements VideoService {
private ReentrantReadWriteLock rwLock=new ReentrantReadWriteLock();
	@Autowired
	private RedisTemplate redisTemplate;
	@Resource(name="videoMapper")
	private VideoMapper videoMapper;
	//查询所有视频
	@Override
	public List<Video> findAllVideos() {
		List<Video> videos=null;
		//设置key的序列化方式,采用字符串方式,可读性好
		this.redisTemplate.setKeySerializer(new StringRedisSerializer());
		//先从redis缓存中查询是否有指定key的缓存数据
		videos=(List<Video>)redisTemplate.opsForValue().get("allVideos");
		//双重检测,双重校验锁
		if(videos==null){
			{
				//从redis获取数据
				videos=(List<Video>)redisTemplate.opsForValue().get("allVideos");
				if(videos==null){
				    System.out.println("查询数据...");
					//说明redis指定key的缓存数据不存在
				    rwLock.writeLock().lock();
					videos=videoMapper.findAllVideos();
					//把数据库查询出来的数据放入redis中,并设置reids的key存活时间为30秒
					redisTemplate.opsForValue().set("allVideos",videos,30,TimeUnit.SECONDS);
					rwLock.writeLock().unlock();
				}else{
					System.out.println("查询的缓存");
				}
			}
		}else{
			System.out.println("查询的缓存");
		}		
		System.out.println(videos);
		return videos;
	}
	

	//添加视频信息
	@Transactional(propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	@Override  
	public boolean addVideo(Video metaData) {
		boolean flag=false;
		System.out.println(metaData);
		this.videoMapper.addVideo(metaData);
		flag=true;
		return flag;
	}

	//更新视频信息
	@Transactional(propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	@Override
	public Result updateVideo(Video video) {
		Result result=new Result();
		this.videoMapper.updateVideo(video);
		result.setStatus(1);
		return result;
	}

	//删除视频信息
	@Transactional(propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	@Override
	public Result deleteVideo(String videoId) {
			Result result=new Result();
			//进行删除视屏操作时清空缓存消息
			this.redisTemplate.delete("allVideos");
			//删除历史,缓存表中的信息
			int rows = this.videoMapper.deleteHistroyCacheByVideoId(videoId);
//			this.videoMapper.deleteVideoByVideoId(videoId);
			System.out.println(rows);
			if(rows >0 ) {
			result.setStatus(1);
			result.setMessage("删除用户成功!!!");}
			else {
				result.setStatus(0);
				result.setMessage("删除用户失败!!");
			}
			return result;
		}

		
	}
	

