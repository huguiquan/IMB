package com.tarena;


import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
                
@SpringBootApplication
@MapperScan(basePackages= {"com.tarena.dao"})
@ComponentScan(basePackages= {"com.tarena"})//扫描当前包及其子包
public class SpringbootImBangApplication extends SpringBootServletInitializer{
	public static void main(String[] args) {
		SpringApplication.run(SpringbootImBangApplication.class, args);
	}
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		return builder.sources(SpringbootImBangApplication.class);

	}
}