package com.tarena.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.tarena.entity.Video;
import com.tarena.service.VideoService;
import com.tarena.vo.Result;

@Controller
@RequestMapping(value="video")
public class VideoController {
	
	@Resource(name="videoService")
	private VideoService videoService;
	
	
	//查询所有视频
	@RequestMapping(value="/findAllVideos",method=RequestMethod.GET)
	@ResponseBody
	public Result findAllVideos() {
		Result result=new Result();
		List<Video> videos=this.videoService.findAllVideos();
		result.setData(videos);
		result.setStatus(1);
		result.setMessage("success!");
		return  result;
	}
	
	//添加视频信息
	@RequestMapping(value="/addVideos",method=RequestMethod.POST)
	@ResponseBody
	public void addVideos(Video metaData) {
		System.out.println("开始插入");
		this.videoService.addVideo(metaData);
		System.out.println("插入成功");
	}
	
	//更新视频信息
	@RequestMapping(value="/updateVideo/{videoId}",method=RequestMethod.POST)
	@ResponseBody
	public Result updateVideo(Video video) {
		Result result = new Result();
		result.setStatus(1);
		result.setMessage("success");
	    result = this.videoService.updateVideo(video);
	    return result;
	}
	
	//删除视频信息
	@RequestMapping(value="/deleteVideo/{videoId}",method=RequestMethod.DELETE)
	@ResponseBody
	public Result deleteVideo(@PathVariable("videoId")String videoId){
		System.out.println("deleteVideo-->"+videoId);
		Result result=new Result();
		result.setStatus(1);
		result.setMessage("success");
		result=this.videoService.deleteVideo(videoId);
		return result;
	}
	
	
	
	
	
}
