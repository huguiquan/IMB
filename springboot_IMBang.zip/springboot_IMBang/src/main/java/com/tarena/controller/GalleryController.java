package com.tarena.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tarena.entity.Gallery;
import com.tarena.service.GalleryService;
import com.tarena.vo.Page;
import com.tarena.vo.Result;


@Controller
@RequestMapping("/qgallery")
public class GalleryController {
	
	@Resource(name="galleryService")
	private GalleryService galleryService;
	
	//通过页面找寻类别信息
	@RequestMapping(value="/findQgallerysByPage",method=RequestMethod.GET)
	@ResponseBody
	public Result findGallerysByPage(Page page){
		Result result=null;
		
		result=this.galleryService.findGallerysByPage(page);
		
		return result;
	}
	
	//添加类别信息
	@RequestMapping(value="addQgallery/{galleryName}",method=RequestMethod.POST)
	@ResponseBody
	public Result addGallery(@PathVariable(value="galleryName") String galleryName){
		Result result=null;
		System.out.println(galleryName);
		
		result=this.galleryService.addGallery(galleryName);
		return result;
	}
	//更新类别
	@RequestMapping(value="updateQgallery",method=RequestMethod.POST)
	@ResponseBody
	public Result updateGallery(Gallery gallery){
		Result result=null;
		
		
		result=this.galleryService.updateGallery(gallery);
		return result;
	}
	//删除类别
	@RequestMapping(value="deleteQgallery/{galleryId}",method=RequestMethod.DELETE)
	@ResponseBody
	public Result deleteGallery(@PathVariable(value="galleryId") String galleryId){
		Result result=new Result();
		System.out.println(galleryId);
		
		result=this.galleryService.deleteGallery(galleryId);
		
		return result;
	}
	
	@RequestMapping(value="/findAllGallerys",method=RequestMethod.GET)
	@ResponseBody
	public Result findAllGallerys(){
		Result result=null;
		//System.out.println("进入controller的findAllGallerys");
		result=this.galleryService.findAllGallerys();
		System.out.println(result);
		
		return result;
	}
}
