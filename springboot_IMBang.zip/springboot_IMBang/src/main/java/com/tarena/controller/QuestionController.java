package com.tarena.controller;

import javax.annotation.Resource;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.tarena.entity.Question;
import com.tarena.service.QuestionService;
import com.tarena.vo.Page;
import com.tarena.vo.Result;



@Controller
@RequestMapping("/question")
public class QuestionController {

	@Resource(name="questionService")
	private QuestionService questionService;
	
	//通过页面获取题目集
	
	@RequestMapping(value="/find",method=RequestMethod.GET)
	@ResponseBody
	public Result findquestionsByPage(Page page){
		
		System.out.println("进入controller的findquestionsByPage。");
		Result result=null;
		
		result=this.questionService.findQuestionsByPage(page);
		result.setStatus(1);
		result.setMessage("找到题目");
		
		return result;
	}
	
	//增加题目
	@RequestMapping(value="addQuestion",method=RequestMethod.POST)
	@ResponseBody
	public Result addQuestion(
			 String qName,
			 String qData,
			Integer qCid){
		Result result=null;
		result=this.questionService.addQuestion(qName,qData,qCid);
		return result;
	}
	
	@RequestMapping(value="/findQuestionById/{findQ}",method=RequestMethod.GET)
	@ResponseBody
	public Result findQuestionById(@PathVariable(value="findQ")Integer id){
		Result result=null;
		System.out.println("进入科目的controller");
		result=this.questionService.findQuestionById(id);
		return result;
	}
	
	
	//更改题目
	@RequestMapping(value="updateQuestion",method=RequestMethod.POST)
	@ResponseBody
	public Result updateQuestion(Question question){
		Result result=null;
		System.out.println(question.getqId()+"   "+question.getqName());
		
		result=this.questionService.updateQuestion(question);
		return result;
	}
	
	//删除题目
	@RequestMapping(value="deleteQuestion/{questionId}",method=RequestMethod.DELETE)
	@ResponseBody
	public Result deleteQuestion(@PathVariable(value="questionId") Integer questionId){
		Result result=new Result();
		System.out.println(questionId);
		
		result=this.questionService.deleteQuestion(questionId);
		
		return result;
	}
	
	
}
