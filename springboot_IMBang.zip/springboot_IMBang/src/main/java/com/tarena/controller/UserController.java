package com.tarena.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.tarena.entity.Page;
import com.tarena.entity.User;
import com.tarena.service.UserService;
import com.tarena.util.ExcelUtil;
import com.tarena.util.VerifyCode;
import com.tarena.vo.Result;

import ch.qos.logback.core.net.SyslogOutputStream;

@Controller
@RequestMapping("user/")
public class UserController {
	
	@Resource(name = "userService")
	private UserService userService;
	private static ThreadLocal<String>  threadLocal = new ThreadLocal<String>();
    //前端用户登录
	@RequestMapping(value = "login/name/{lName}/password/{pwd}", method = RequestMethod.POST)
	@ResponseBody // {"status":1,"message":"登录成功","data":{"id":1,"loginName":"wt_zss@126.com"}}
	public Result login(
		 @PathVariable(value = "lName") String loginName, 
	     @PathVariable(value = "pwd") String password,
	     HttpSession session) {
		//System.out.println(loginName + "  " + password);
		Result result = null;
        
		// 调用登录业务
		result = this.userService.login(loginName, password,session);
		
		return result;

	}
	//查询用户名是否存在
		@RequestMapping(value = "findUserByName/{lName}", method = RequestMethod.GET)
		@ResponseBody // {"status":1,"message":"登录成功","data":{"id":1,"loginName":"wt_zss@126.com"}}
		public Result findUserByName(
			 @PathVariable(value = "lName") String loginName,
		     HttpSession session) {
			Result result = null;
			// 调用登录业务
			result = this.userService.findUserByName(loginName);
			return result;
		}
	    //后端用户登录
		@RequestMapping(value = "loginBack/name/{lName}/password/{pwd}", method = RequestMethod.POST)
		@ResponseBody // {"status":1,"message":"登录成功","data":{"id":1,"loginName":"wt_zss@126.com"}}
		public Result loginBack(
			 @PathVariable(value = "lName") String loginName, 
		     @PathVariable(value = "pwd") String password,
		     HttpSession session) {
			//System.out.println(loginName + "  " + password);
			Result result = null;
			// 调用登录业务
			result = this.userService.loginBack(loginName, password,session);
			return result;

		}
	    //前端用户注册
		@RequestMapping(value = "registUser/name/{lName}/password/{pwd}", method = RequestMethod.POST)
		@ResponseBody // {"status":1,"message":"登录成功","data":{"id":1,"loginName":"wt_zss@126.com"}}
		public Result registUser(
			 @PathVariable(value = "lName") String loginName, 
		     @PathVariable(value = "pwd") String password
		     ) {
			//System.out.println(loginName + "  " + password);
			Result result = null;
			// 调用登录业务
			result = this.userService.registUser(loginName, password);
			return result;

		}
		//注销
		public Result logout(HttpSession session){
			Result result = null;
			//清除session
			session.invalidate();
			result.setStatus(1);
			result.setMessage("清除成功");
			return result;
		}
		//动态生成验证码
		@RequestMapping(value="doGet1")
		public void doGet(HttpServletRequest req, HttpServletResponse resp)
				throws ServletException, IOException {
			// 创建VerifyCode的实例
			OutputStream outputStream = resp.getOutputStream();
			VerifyCode vc=new VerifyCode();
			// 调用其方法动态生成一张验证码图片
			HttpSession session = req.getSession();
			vc.drawImage(outputStream);
			// 将图片直接写入到response缓冲区中
			String text=vc.getCode();
			session.setAttribute("code", text);
			// 获取正确的验证码内容
			//System.out.println("验证码="+text);
			// 将正确的验证码内容存入Session作用域
			// 将正确的验证码内容存入ServletContext作用域
			// 多用户情况下会有并发问题
			//this.getServletContext().setAttribute("code", text);
		}
		//前台ajax验证后台验证码
		@RequestMapping(value="doGet/valiName/{codeText}",method=RequestMethod.POST)
		@ResponseBody
		public Result doGetCode(HttpServletRequest req, HttpServletResponse resp,@PathVariable("codeText") String codeText)
				throws ServletException, IOException{
		    Result result=new Result();
		    String code=(String) req.getSession().getAttribute("code");
            /*System.out.println("system code " +req.getSession().getAttribute("code"));
            System.out.println("user code  " + codeText);*/
            if((code.toLowerCase()).equals((codeText.toLowerCase()))) {
              result.setStatus(1);
            	result.setMessage("验证成功！");
            }else {
            	result.setStatus(0);
            	result.setMessage("验证码错误，重新输入！");
            }
            return result;
		}
		//前台ajax验证后台验证码
				@RequestMapping(value="doGetBack/valiName/{codeText}",method=RequestMethod.POST)
				@ResponseBody
				public Result doGetCodeBack(HttpServletRequest req, HttpServletResponse resp,@PathVariable("codeText") String codeText)
						throws ServletException, IOException{
				    Result result=new Result();
				    String code=(String) req.getSession().getAttribute("code");
		            /*System.out.println("system code " +req.getSession().getAttribute("code"));
		            System.out.println("user code  " + codeText);*/
		            if((code.toLowerCase()).equals((codeText.toLowerCase()))) {
		              result.setStatus(1);
		            	result.setMessage("验证成功！");
		            }else {
		            	result.setStatus(0);
		            	result.setMessage("验证码错误，重新输入！");
		            }
		            return result;
				}
				   //页面导出
				@RequestMapping(value="/exportUser",method=RequestMethod.GET)
			   //
			   public void exportUser(HttpServletRequest request,HttpServletResponse response){
				   //测试是否进入方法
					//System.out.println(2222);
			      //查询用户信息	
				  List<User> users=this.userService.findAllUser(); 
				   //result.setStatus(1);
				  String name="爱码邦人员信息统计表.xls";
				  byte[] data=ExcelUtil.write2Excel(users);
			     //把字节数据下载到浏览器客户端
				  try {
						response.setContentType("application/x-msdownload");
						//显示下载的条
						response.setHeader("Content-Disposition", "attachment;fileName="+new String(name.getBytes("gb2312"), "ISO-8859-1") + ".xls");
						response.setContentLength(data.length);
						OutputStream os=response.getOutputStream();
						os.write(data);
						os.flush();
						os.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}	
			//新增用户
			@RequestMapping(value="addUser",method=RequestMethod.POST)
			//@ResponseBody
			public void addUser(User user,HttpServletRequest request,HttpServletResponse resoponse,MultipartFile addPicture) {
			  // System.out.println(addPicture);
				this.userService.addUser(user,request,resoponse,addPicture);	
			}
			
			@RequestMapping(value="findUsersByPage",method=RequestMethod.GET)
			@ResponseBody
			public Result findUsersByPage(Page page){
				//System.out.println("aaa");
				Result result=null;
				result=this.userService.findUsersByPage(page);		
				return result;
			}
			
			//根据id查询用户
			@RequestMapping(value="findUserById/{userId}",method=RequestMethod.GET)
			@ResponseBody
			public Result findUserById(@PathVariable(value="userId") String userId){
				Result result=null;
				result=this.userService.findUserById(userId);
				return result;
			}
			
			
			//更新用户
			@RequestMapping(value="updateUser",method=RequestMethod.POST)
			//@ResponseBody
			public void updateUser(User user,
		           MultipartFile addPicture,
					HttpServletRequest request,
					HttpServletResponse response){
					this.userService.updateUser(user,addPicture,request,response);
				
			}
			
			//删除用户
			@RequestMapping(value="deleteUser/{userId}",method=RequestMethod.DELETE)
			@ResponseBody
			public Result deleteUser(@PathVariable(value="userId") String userId){
				//System.out.println("deleteUser-->"+userId);
				Result result=null;
				result=this.userService.deleteUser(userId);
				return result;
			}
}
