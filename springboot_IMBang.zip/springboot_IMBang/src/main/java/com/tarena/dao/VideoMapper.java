package com.tarena.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.tarena.entity.Video;

public interface VideoMapper {
	
	//查询所有视频
	public List<Video> findAllVideos();

	//添加一个视频信息进入数据表
	public void addVideo(Video metaData);

	//更新视频信息
	public void updateVideo(Video video);
	
	//根据视频id删除此视频历史和缓存中的数据
	public int deleteHistroyCacheByVideoId(String videoId);
	
}
