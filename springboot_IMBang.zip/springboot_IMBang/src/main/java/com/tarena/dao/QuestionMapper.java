package com.tarena.dao;

import java.util.List;

import com.tarena.entity.Question;
import com.tarena.vo.Page;

public interface QuestionMapper {

	//通过页面，获取问题集
	List<Question> getQuestionsByPage(Page page);

	//添加题目
	Integer addQuestion(Question question);

	//更新题目
	Integer updateQuestion(Question question);

	//删除题目
	void deleteQuestion(Integer questionId);

	//获取总记录数
	Integer getCount(Page page);

	//获取题目类型名
	String getCategoryNameById(Integer qCid);

	//通过Id找对应题目
	Question findQuestionById(Integer id);

	
	

	

	
	
}
