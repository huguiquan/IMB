package com.tarena.dao;

import java.util.List;

import com.tarena.entity.Page;
import com.tarena.entity.User;
import com.tarena.vo.Result;

public interface UserMapper {
    //普通用户登录
	public String login(User user);
    //注册用户
	public void registUser(User user);
	//后端用户登录
	public String loginBack(User user);
	// 查询用户是否存在
	public int findUserByName(String loginName);
	//添加用户
		public void addUser(User user);
		//
		public Result findUsersByPage();
		//计算总页数
		public int getCount(Page page);
		//
		public List<User> getUserByPage(Page page);
		//编辑用户
		public void updateUser(User user);
		//查询所有用户
		public List<User> findAllUser();
		//删除用户
		public void deleteUserByUserId(String userId);
		public User findUserById(String userId);
		

}
