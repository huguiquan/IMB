package com.tarena.dao;

import java.util.List;

import com.tarena.entity.Gallery;
import com.tarena.vo.Page;



public interface GalleryMapper {
	//客户类别的分页
	public int getCount(Page page);
	public List<Gallery> getGallerysByPage(Page page);
	//添加科目类别
	public int addGallery(Gallery gallery);
	//更新科目
	public int updateGallery(Gallery gallery);
	//删除科目
	public int deleteGallery(String galleryId);
	//查询所有科目信息
	public List<Gallery> findAllGallerys();
	//查询科目中类别Id对应的类别名字
	public String getCategoryNameById(Integer qCid);
}
