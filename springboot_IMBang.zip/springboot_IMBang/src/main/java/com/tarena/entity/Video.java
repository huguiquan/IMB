package com.tarena.entity;

import java.io.Serializable;

public class Video implements Serializable{
	private String video_id;
	private String video_title;
	private String video_forsale;
	private String user_id;
	public String getVideo_id() {
		return video_id;
	}
	public void setVideo_id(String video_id) {
		this.video_id = video_id;
	}
	public String getVideo_title() {
		return video_title;
	}
	public void setVideo_title(String video_title) {
		this.video_title = video_title;
	}
	public String getVideo_forsale() {
		return video_forsale;
	}
	public void setVideo_forsale(String video_forsale) {
		this.video_forsale = video_forsale;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	@Override
	public String toString() {
		return "Video [video_id=" + video_id + ", video_title=" + video_title + ", video_forsale=" + video_forsale
				+ ", user_id=" + user_id + "]";
	}
	
	

	
	

	
	
	
	
	
	
}
