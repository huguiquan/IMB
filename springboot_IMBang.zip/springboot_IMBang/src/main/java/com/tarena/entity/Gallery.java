package com.tarena.entity;

import java.io.Serializable;

//题目的类型
public class Gallery  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer cId;
	private String cName;
	public Integer getcId() {
		return cId;
	}
	public void setcId(Integer cId) {
		this.cId = cId;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	@Override
	public String toString() {
		return "QCategory [cId=" + cId + ", cName=" + cName + "]";
	}
	
	
	
	
	
}
