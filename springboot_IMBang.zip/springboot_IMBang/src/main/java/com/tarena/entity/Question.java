package com.tarena.entity;

import java.io.Serializable;

public class Question implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5942740997640428648L;
	
	private Integer qId;
	private String qName;
	private String qData;
	private Integer qCid;
	private String qCategory;
	
	
	
	public String getqCategory() {
		return qCategory;
	}
	public void setqCategory(String qCategory) {
		this.qCategory = qCategory;
	}
	public Integer getqCid() {
		return qCid;
	}
	public void setqCid(Integer qCid) {
		this.qCid = qCid;
	}
	public Integer getqId() {
		return qId;
	}
	public void setqId(Integer qId) {
		this.qId = qId;
	}
	public String getqName() {
		return qName;
	}
	public void setqName(String qName) {
		this.qName = qName;
	}
	public Object getqData() {
		return qData;
	}
	public void setqData(String qData) {
		this.qData = qData;
	}
	@Override
	public String toString() {
		return "Question [qId=" + qId + ", qName=" + qName + ", qData=" + qData + ", qCid=" + qCid + ", qCategory="
				+ qCategory + "]";
	}
	
	
	
	
}
