
var userId;

function deleUserClick(uid){
	userId=uid;
	ShowDiv('DELETEUSERS','deleteuser');
}



$(function(){
	//第一次点击用户管理是，带有模糊条件的查询,第一页
	findUsersByPage(1);
	
	//为模糊添加click事件
	$("#search").click(function(){
		
		findUsersByPage(1);
	});

	  //为新增用户添加click事件
    $("#addUserPanel form").submit(function(){
      	
      	
      	return addUser();
      });
    
    //导出
    $("#exprot_user").click(function(){
  
    	

    	//转入要调用controller的方法
    	window.location.href="user/exportUser";


    	  });
	
});

//更新用户的click
function updateUserClick(uid){
	
	userId=uid;
	
	ShowDiv('MyDiv','fade');
	$.ajax({
		url:"user/findUserById/"+userId,
		type:"get",
	    dataType:"json",
	    success:function(result){
	    	if(result.status==1){
	    		var user=result.data;
	    	
	    		$("#user-name").val(user.loginName);
	    		$("#user-nickname").val(user.nickName);
	    		$("#user-age").val(user.age);
	    		if(user.sex=='男'){
	    			
	    			$("#user_sex input[value=男]").attr("checked","checked");
	    		}else{
	    			$("#user_sex input[value=女]").attr("checked","checked");
	    		}
	    	}
	    },
	    error:function(){
	    	
	    	alert("数据传输失败");
	    }
	});
}


//添加新增用户
function addUser(){
var loginName=$("#addUserPanel #add_loginName").val();
var password=$("#addUserPanel #add_inputPassword").val();
var password2=$("#addUserPanel #add_inputPassword2").val();
var nickName=$("#addUserPanel #add_nickName").val();
var roleId=$("#addUserPanel #roleCategory").val();
var age=$("#addUserPanel #add_age").val();
var sex=$("#addUserPanel input[name=user-type]:checked").val();
if(password!=password2){
   alert("两次密码不一致");
   return false;
}
if(age<1 || age>200){
  alert("年龄不合法");
  return false;
}
$.ajaxFileUpload({
	url:"user/addUser",
	secureuri:false,
	fileElementId:"addHeadPicture",
	type:"post",
	data:{
		"loginName":loginName,
		"password":password,
		"nickName":nickName,
		"age":age,
		"sex":sex,
		
	},
	dataType:"text",
	success:function(data,status){
		//alert(data);
		data=data.replace(/<PRE.*?>/g,'');
		data=data.replace("<PRE>",'');
		data=data.replace("</PRE>",'');
		data=data.replace(/<pre.*?>/g,'');
		data=data.replace("<pre>",'');
		data=data.replace("</pre>",'');
		alert("添加用户成功");
		findUsersByPage(1);
	},
	error:function(){
		alert("请求失败!");
		//更新页面
		
	}
});

$("#addUserPanel").toggle();
return false;
}





//查询
function findUsersByPage(currentPage){
	
	//处理模糊关键字
	var userKeyword=$("#searchip input[type=text]").val();
    if(userKeyword==""){
    	userKeyword="undefined";
    }
  //alert(currentPage);
    //发送异步请求
    $.ajax({
    	url:"user/findUsersByPage",
    	type:"get",
    	data:{
    		"currentPage":currentPage,
    		"userKeyword":userKeyword,
    	},
    	dataType:"json",
    	success:function(result){
    		//分页查询数据成功，给表格赋值
    		if(result.status==1){
    			//给tr赋值
    			var page=result.data;
    			var users=page.data;
    			//清空表格的tbody
    			$("#user_table tbody").html("");
    			$(users).each(function(index,user){
    				//循环赋值
    				var tr=`<tr>
                    <td><input type="checkbox"></td>
                    <td>${user.loginName}</td>
                    <td><a href="#">${user.id}</a></td>
                    <td>${user.nickName}</td>
                    <td class="am-hide-sm-only">${user.sex}</td>
                    <td class="am-hide-sm-only">${new Date(user.regDate).toLocaleDateString()}</td>
                    <td>
                        <div class="am-btn-toolbar">
                            <div class="am-btn-group am-btn-group-xs">
                            <a onclick="updateUserClick('${user.id}')" ><input type="hidden" value="" class="am-btn am-btn-default am-btn-xs am-hide-sm-only"><span class="am-icon-edit">编辑&nbsp&nbsp&nbsp&nbsp</input></a>
       
                            <a onclick="deleUserClick('${user.id}')" ><input type="hidden" value="" class="am-btn am-btn-default am-btn-xs am-hide-sm-only"><span class="am-icon-trash-o"></span> 删除</input></a>
  
                            </div>
                        </div>
                    </td>
                </tr>`;
    				
    				$("#user_table tbody").append(tr);
    				
    			});
    			//给分页条赋值
    			$("#user_pagination").html('');
    			//alert(page.totalPage);
    			//清空原有的分页条
				var options={
					currentPage:currentPage,//当前页,当前页面显示数据的那个页号
					totalPages:page.totalPage,//总页数
					numberOfPages:5,//超链接的个数
					onPageClicked:function(event, originalEvent, type,page){
					
						findUsersByPage(page);
					}					
				};
				$("#user_pagination").bootstrapPaginator(options);
    		}
    		
    		
    		
    	},
    	error:function(){
    		
    		alert("请求失败");
    	}
    });
	
	
}


//编辑用户
function UpdataUser(){
	
	//alert(userId);
	var loginName=$("#user-name").val();
	//alert(loginName);
	var password=$("#user-password").val();
	var password2=$("#user-password2").val();
	var nickName=$("#user-nickname").val();
	var age=$("#user-age").val();
	//var sex=$("#user-sex").val();	
	var sex=$("#user_sex input[name=user_type]:checked").val();
	//alert("sex:"+sex);
	if(password!=password2){
		alert("两个密码要相同");
		$("#user-password2").focus();
		return false;
	}
	if(age<1 || age>200){
		alert("年龄不符合");
		$("#editUser form #age").focus();
		return false;
	}

	//异步请求更新用户数据(借助ajaxfileupload.js框架)
	$.ajaxFileUpload({
		url:"user/updateUser",
		secureuri:false,
		fileElementId:"updateHeadpicture",
		type:"post",
		data:{
			"id":userId,
			"loginName":loginName,
			"password":password,
			"nickName":nickName,
			"age":age,
			"sex":sex,
		},
		dataType:"text",
		success:function(data,status){
			//alert(data);
			data=data.replace(/<PRE.*?>/g,'');
			data=data.replace("<PRE>",'');
			data=data.replace("</PRE>",'');
			data=data.replace(/<pre.*?>/g,'');
			data=data.replace("<pre>",'');
			data=data.replace("</pre>",'');
			
			alert("请求成功")
			
			//关掉modal模态框
			CloseDiv2()
			
			//更新页面
			findUsersByPage(1);
		},
		error:function(){
			alert("请求失败!");
		}
	});
	return false;
};


//删除用户
function DeleteUser(){
	
  
	alert("deleteUser111-->"+userId);
	$.ajax({
		url:"user/deleteUser/"+userId,
		type:"delete",
		dataType:"json",
		success:function(result){
			
			alert(result.message);
			CloseDiv("DELETEUSERS","deleteuser");
			//更新页面
			findUsersByPage(1);
		},
		error:function(){
			alert("请求失败!!!");
		}
	});
	
	
};





//弹出隐藏层
function ShowDiv(show_div,bg_div){
	var scrollHeight = document.body.scrollHeight; //文档高度
	document.getElementById(bg_div).style.height=scrollHeight+'px';
	
	document.getElementById(show_div).style.display='block';
	document.getElementById(bg_div).style.display='block';
};
//关闭弹出层
function CloseDiv(show_div,bg_div)
{
	//document.getElementById("label").value = '';
	document.getElementById(show_div).style.display='none';
	document.getElementById(bg_div).style.display='none';
};
//关闭弹出层
function CloseDiv2()
{
	document.getElementById("MyDiv").style.display='none';
	document.getElementById("fade").style.display='none';
}

	    

