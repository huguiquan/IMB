var Video_id;
$(function(){
	checkVideo();
});
function checkVideo(){
		// 异步判断该视屏是否存在，如果已存在，给用户已提示哦
		$.ajax({
			url:"/video/findAllVideos",
			type:"get",
			dataType : "json",
			success:function(result){
				// 如果返回数据不为空，更改“video信息”
				if(result.status==1){
					// 清空表格的video_tbody表格
					$("#video_table tbody").html("");
					
					$(result.data).each(function(index,video){
						var tr=`<tr id="tr_"+${video.video_id}>
                            <td><input type="checkbox"></td>
                            <td>${video.video_id}</td>
                            <td><a href="#">${video.video_title}</a></td>
                            <td>${video.video_forsale}</td>
                            <td class="am-hide-sm-only">${video.user_id}</td>
                            <td>
                                <div class="am-btn-toolbar">
                                    <div class="am-btn-group am-btn-group-xs">
                                    
							            <a href="javascript:updateVideoclick('${video.video_id}')" class="am-btn am-btn-default am-btn-xs am-text-secondary"><span class="am-icon-pencil-square-o"></span>编辑</a>
                                        <a href="javascript:deleteVideo('${video.video_id}')" class="am-btn am-btn-default am-btn-xs am-text-danger am-hide-sm-only"><span class="am-icon-trash-o"></span> 删除</a>
                                    </div>
                                </div>
                            </td>
                        </tr>`;
							$("#video_table tbody").append(tr);
					});
					
					// art.dialog({icon:'error', title:'友情提示', drag:false,
					// resize:false, content:'该房室在系统中已经存在哦，\n请维护其他视屏数据',
					// ok:true,});
					 return false;
				}
			}
		});
}

function deleteVideo(video_Id){
	$.ajax({
		url:"/video/deleteVideo/"+video_Id,
		type:"delete",
		dataType:"json",
		success:function(result){
			if(result.status==1){
				alert(result.message);
				checkVideo();
			}
		}
	});
};

function updateVideoclick(video_id){
	Video_id=video_id;
	ShowDiv('MyDiv','fade');
	
}

function updateVideo(){
	var video_title=$("#video_title1").val();
	var video_forsale=$("#video_forsale1 input[name=user_type]:checked").val();
	var user_id=$("#user_id1").val();
	
	$.ajax({
		url:"/video/updateVideo/"+Video_id,
		type:"post",
		data:{
			"video_id":Video_id,
			"video_title":video_title,
			"video_forsale":video_forsale,
			"user_id":user_id,
		},
		dataType:"json",
		success:function(result){
			if(result.status==1){
				alert(result.message);
				checkVideo();
			}else{
				alert("服务器繁忙请稍候再试!!")
			}
			
		}
	});
}

	
function addVideo(){
	var video_id=$("#video_id").val();
	var video_title=$("#video_title").val();
	var video_forsale=$("#video_forsale input[name=user_type]:checked").val();
	var user_id=$("#user_id").val();
	$.ajax({
		url:"/video/addVideos",
		type:"post",
		data:{
			"video_id":video_id,
			"video_title":video_title,
			"video_forsale":video_forsale,
			"user_id":user_id
		},
		dataType:"json",
		success:function(result){
			if(result.status==1){
				alert(result.message);
				checkVideo();
			}
		}
		
	});
}




//弹出隐藏层
function ShowDiv(show_div,bg_div){
	var scrollHeight = document.body.scrollHeight; //文档高度
	document.getElementById(bg_div).style.height=scrollHeight+'px';
	
	document.getElementById(show_div).style.display='block';
	document.getElementById(bg_div).style.display='block';
};
//关闭弹出层
function CloseDiv(show_div,bg_div)
{
	//document.getElementById("label").value = '';
	document.getElementById(show_div).style.display='none';
	document.getElementById(bg_div).style.display='none';
};
//关闭弹出层
function CloseDiv2()
{
	document.getElementById("MyDiv").style.display='none';
	document.getElementById("fade").style.display='none';
}