var findC;
$(function (){
	//alert(getCookie("loginAddress"))
   findC=getCookie("loginName2");
   autoLogin(findC);
   $("#logout").click(function(){
	   logout(findC);
   });
});
//注销
function logout(deleteC){
	delCookie("loginName2");
};
function autoLogin(autoLogin){
	// 带cookie的访问
	// 或者带有记住用户名的cookie
	findA = getCookie("loginAddress");
	//alert(findA);
	 if(autoLogin!=""){
		$("#login_groups").html(`<li><a>${autoLogin}</a></li><li id="logout" class="pull-left">
				<a href="login.html">注销</a>
				</li>`);
	 }else if(findA!=""){
		 $("#login_groups").html(`<li><a>${findA}</a></li><li id="logout" class="pull-left">
					<a href="login.html">注销</a>
					</li>`);
	 }else{
		 $("#login_id").html(`<li class="pull-left">
							<a href="register.html">注册</a>
						</li>`)
		 $("#login_id2").html(`<li class="pull-left">
			<a href="login.html">登录</a>
		</li>`)
	 }
};